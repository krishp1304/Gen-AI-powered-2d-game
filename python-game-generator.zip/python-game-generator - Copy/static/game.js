// game.js - Upgraded Phaser frontend with better gameplay
const container = document.getElementById('game-container');
const statusEl = document.getElementById('status');
let currentGame = null;
let lastConfig = null;

document.getElementById('btn-gen-mock').onclick = async () => { await generateGame({ mock: true }); };
document.getElementById('btn-gen-real').onclick = async () => { await generateGame({ mock: false }); };
document.getElementById('btn-reset').onclick = () => { destroyGame(); status('Reset'); };
document.getElementById('btn-restart').onclick = () => { if(lastConfig) buildPhaserGame(lastConfig); };

async function uploadImage(file) {
  if (!file) return null;
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetch('/upload', { method: 'POST', body: fd });
  const j = await res.json();
  return (j.ok && j.url) ? j.url : null;
}

function status(t) { statusEl.innerText = t; }

async function generateGame({ mock=false } = {}) {
  status('Uploading image...');
  const file = document.getElementById('image').files[0];
  const imgUrl = await uploadImage(file);
  status('Requesting generate...');
  const prompt = document.getElementById('prompt').value;
  const res = await fetch('/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, imageUrl: imgUrl, mock })
  });
  const j = await res.json();
  if (!j.ok) { status('Error: ' + (j.error||'unknown')); return; }
  status('Building game...');
  buildPhaserGame(j.game);
}

function destroyGame() {
  if (currentGame) { try { currentGame.destroy(true); } catch(e) {} currentGame = null; container.innerHTML=''; }
}

// Helper textures
function createRectTexture(scene, key, w, h, color) {
  const g = scene.add.graphics();
  g.fillStyle(Phaser.Display.Color.HexStringToColor(color).color, 1);
  g.fillRect(0, 0, w, h);
  g.generateTexture(key, w, h);
  g.destroy();
}
function createCircleTexture(scene, key, r, color) {
  const g = scene.add.graphics();
  g.fillStyle(Phaser.Display.Color.HexStringToColor(color).color, 1);
  g.fillCircle(r, r, r);
  g.generateTexture(key, r*2, r*2);
  g.destroy();
}

function buildPhaserGame(cfg) {
  destroyGame();
  lastConfig = cfg;
  const width = cfg.width || 900, height = cfg.height || 600, gravity = cfg.gravity || 900;
  const phaserConfig = {
    type: Phaser.AUTO, width, height, parent: 'game-container',
    physics: { default: 'arcade', arcade: { gravity: { y: gravity }, debug: false } },
    scene: { preload(){}, create(){ buildScene(this,cfg,width,height); } }
  };
  currentGame = new Phaser.Game(phaserConfig);
  status('Game running');
}

function buildScene(scene,cfg,width,height){
  scene.add.rectangle(width/2,height/2,width,height,0x0b0b0b);

  // Platforms
  const platforms=scene.physics.add.staticGroup();
  createRectTexture(scene,'platform-tex',100,20,'#444444');
  (cfg.platforms||[]).forEach(p=>{
    const plat=platforms.create(p.x,p.y,'platform-tex');
    plat.setDisplaySize(p.w,p.h); plat.refreshBody();
  });

  // Player
  const pl=cfg.player||{w:36,h:48,color:'#00aaff',speed:400,jump:500};
  createRectTexture(scene,'player-tex',pl.w,pl.h,pl.color||'#00aaff');
  const player=scene.physics.add.sprite(100,height-150,'player-tex');
  player.setCollideWorldBounds(true);
  player.body.setSize(pl.w,pl.h,true);
  player.setBounce(0.1);
  player.speed=pl.speed||400;
  player.jumpPower=pl.jump||500;
  player.doubleJumpAvailable=true;
  scene.physics.add.collider(player,platforms);

  // Collectibles
  const collectibles=scene.physics.add.group();
  createCircleTexture(scene,'star-tex',10,'#ffd700');
  (cfg.collectibles||[]).forEach(c=>{
    const s=collectibles.create(c.x,c.y,'star-tex');
    s.type=c.type||'star';
  });
  scene.physics.add.collider(collectibles,platforms);

  // Enemies
  const enemies=scene.physics.add.group();
  createRectTexture(scene,'enemy-tex',36,30,'#ff4466');
  (cfg.enemies||[]).forEach(e=>{
    const en=enemies.create(e.x,e.y,'enemy-tex');
    en.speed=e.speed||100;
    en.setCollideWorldBounds(true);
    en.setBounce(1,0);
    if(cfg.gameType==='platformer' || cfg.gameType==='shooter'){
      en.setVelocityX((Math.random()>0.5?1:-1)*en.speed);
    }
  });
  scene.physics.add.collider(enemies,platforms);
  scene.physics.add.collider(enemies,enemies);

  // Score
  let score=0; const scoreText=scene.add.text(12,12,'Score: 0',{fontSize:'20px',fill:'#fff'});

  // Collectibles pickup
  scene.physics.add.overlap(player,collectibles,(p,c)=>{
    c.destroy(); score+=10; scoreText.setText('Score: '+score);
    // play collect sound here
    if(cfg.gameType==='platformer' && collectibles.countActive(true)===0){
      showEnd(scene,'You Win!', '#0f0');
    }
  });

  // Collide with enemies
  scene.physics.add.collider(player,enemies,()=>{
    scene.cameras.main.shake(300,0.01); // feedback
    showEnd(scene,'Game Over','#f33');
  });

  // Controls
  const cursors=scene.input.keyboard.createCursorKeys();
  const space=scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

  // Bullets
  const bullets=scene.physics.add.group();
  scene.physics.add.collider(bullets,platforms,b=>b.destroy());
  scene.physics.add.overlap(bullets,enemies,(b,en)=>{
    b.destroy(); en.destroy(); score+=20; scoreText.setText('Score: '+score);
    scene.cameras.main.flash(150,255,255,255); // hit flash
  });

  // Shooter tweak
  if(cfg.gameType==='shooter'){ player.setGravityY(0); player.body.setAllowGravity(false); }

  // Dodger tweak: enemies rain down
  if(cfg.gameType==='dodger'){
    scene.time.addEvent({delay:1000,loop:true,callback:()=>{
      const x=Phaser.Math.Between(20,width-20);
      const en=enemies.create(x,-20,'enemy-tex');
      en.setVelocityY(Phaser.Math.Between(120,200 + score/5));
    }});
  }

  // Difficulty scaling
  scene.time.addEvent({delay:15000,loop:true,callback:()=>{
    enemies.children.iterate(e=>{ if(e) e.setVelocityX(e.body.velocity.x*1.2); });
  }});

  // Update loop
  scene.events.on('update',()=>{
    // Movement with deceleration
    if(cursors.left.isDown) player.setVelocityX(-player.speed);
    else if(cursors.right.isDown) player.setVelocityX(player.speed);
    else player.setVelocityX(player.body.velocity.x*0.8);

    // Jump + double jump
    if(cursors.up.isDown && player.body.blocked.down){
      player.setVelocityY(-player.jumpPower);
      player.doubleJumpAvailable=true;
    } else if(cursors.up.isDown && player.doubleJumpAvailable && !player.body.blocked.down){
      player.setVelocityY(-player.jumpPower*0.9);
      player.doubleJumpAvailable=false;
    }

    // Shoot
    if(Phaser.Input.Keyboard.JustDown(space) && cfg.gameType==='shooter'){
      const b=bullets.create(player.x+30,player.y,'star-tex');
      b.setVelocityX(500);
      b.body.allowGravity=false;
      // play shoot sound here
    }
  });

  function showEnd(scene,msg,color){
    scene.add.text(width/2-120,height/2-40,msg,{fontSize:'48px',fill:color});
    scene.physics.pause();
  }
}
