# app.py -- Flask backend for Python-only Game Generator (Rule-based, always playable)
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os, uuid, json

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__, static_folder='static', static_url_path='/')
CORS(app)

@app.route('/upload', methods=['POST'])
def upload():
    if 'image' not in request.files:
        return jsonify({'ok': False, 'error': 'No file part'}), 400
    f = request.files['image']
    if f.filename == '':
        return jsonify({'ok': False, 'error': 'No selected file'}), 400
    fn = str(uuid.uuid4()) + os.path.splitext(f.filename)[1]
    path = os.path.join(UPLOAD_FOLDER, fn)
    f.save(path)
    url = '/uploads/' + fn
    return jsonify({'ok': True, 'url': url})

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/generate', methods=['POST'])
def generate():
    body = request.get_json() or {}
    prompt = body.get('prompt', 'fun platformer')
    imageUrl = body.get('imageUrl')
    mock = body.get('mock', True)
    try:
        game = generate_game(prompt, imageUrl, mock)
        return jsonify({'ok': True, 'game': game})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500

# -----------------------
# Rule-based generator (always playable)
# -----------------------

def generate_game(prompt, imageUrl=None, mock=True):
    return generate_mock(prompt, imageUrl)

def generate_mock(prompt, imageUrl):
    """ Rule-based deterministic generator (always playable). """
    p = (prompt or '').lower()
    gameType = 'platformer'
    if 'shoot' in p or 'gun' in p or 'space' in p:
        gameType = 'shooter'
    if 'dodge' in p or 'avoid' in p or 'meteor' in p:
        gameType = 'dodger'

    width, height = 900, 600
    player = {'w':40,'h':48,'color':'#00aaff','speed':400,'jump':500}

    if gameType == 'platformer':
        platforms = [
            {'x':450,'y':580,'w':900,'h':40},   # ground
            {'x':200,'y':450,'w':200,'h':20},
            {'x':700,'y':350,'w':200,'h':20}
        ]
        collectibles = [
            {'x':200,'y':410,'type':'star'},
            {'x':700,'y':310,'type':'star'},
            {'x':450,'y':250,'type':'star'}
        ]
        enemies = [
            {'x':600,'y':520,'type':'slime','speed':100}
        ]
        gravity = 900

    elif gameType == 'dodger':
        platforms = [{'x':450,'y':590,'w':900,'h':20}]  # ground
        collectibles = []
        enemies = [
            {'x':200,'y':-20,'type':'meteor','speed':180},
            {'x':600,'y':-20,'type':'meteor','speed':200}
        ]
        gravity = 400

    elif gameType == 'shooter':
        platforms = [{'x':450,'y':590,'w':900,'h':20}]  # ground
        collectibles = [{'x':100,'y':540,'type':'ammo'}]
        enemies = [
            {'x':300,'y':520,'type':'tank','speed':80},
            {'x':600,'y':520,'type':'tank','speed':80}
        ]
        gravity = 600

    return {
        'gameType': gameType,
        'width': width,
        'height': height,
        'gravity': gravity,
        'player': player,
        'platforms': platforms,
        'collectibles': collectibles,
        'enemies': enemies,
        'meta': {'from':'rule-based'}
    }

# -----------------------

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
